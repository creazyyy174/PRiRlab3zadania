public class Parking
{
    static int ilosc_samochodow=100;
    static int ilosc_miejsc=5;
    static Parking parking;
    public Parking()
    {
    }

    public Parking(int ilosc_miejsc, int ilosc_samochodow) {
    }

    public static void main(String[] args)
    {
        parking=new Parking(ilosc_miejsc, ilosc_samochodow);
        for(int i=0;i<ilosc_samochodow;i++)
            new Samochod(i, parking).start();
    }

    public void wyjdz(int id)
    {
        System.out.println("Samochod "+id+" wyjezdza z parkingu");
    }
    public void wejdz(int id)
    {
        System.out.println("Samochod "+id+" wjezdza na parking");
    }
    public void oplata(int id)
    {
        int oplata=(int)(Math.random()*10+1);
        System.out.println("Samochod "+id+" zaplacil "+oplata+" zl");
    }
}
