import java.util.Random;

public class Samochod extends Thread
{
    private int id;
    private Parking parking;
    private Random random;
    public Samochod(int id, Parking parking)
    {
        this.id=id;
        this.parking=parking;
        random=new Random();
    }
    public void run()
    {
        while(true)
        {
            parking.wejdz(id);
            try
            {
                sleep(random.nextInt(1000));
            }
            catch(InterruptedException e)
            {
            }
            parking.oplata(id);
            parking.wyjdz(id);
        }
    }

}
