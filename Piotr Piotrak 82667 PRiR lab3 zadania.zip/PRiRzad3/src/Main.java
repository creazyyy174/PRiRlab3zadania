public class Main {

    public static void main(String[] args)
    {
        Picture pic = new Picture("picture.jpg");
        pic.negatyw();
        pic.show();

    }
}
