import java.awt.image.*;
import java.io.*;
import javax.imageio.*;

public class Picture
{
    public Picture(String path)
    {
        try
        {
            image = ImageIO.read(new File(path));
        }
        catch (IOException e)
        {
            System.out.println("Błąd wczytywania obrazka");
        }
    }

    public void negatyw()
    {
        int width = image.getWidth();
        int height = image.getHeight();
        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                int rgb = image.getRGB(i, j);
                int r = (rgb >> 16) & 0xFF;
                int g = (rgb >> 8) & 0xFF;
                int b = (rgb & 0xFF);
                r = 255 - r;
                g = 255 - g;
                b = 255 - b;
                rgb = (r << 16) | (g << 8) | b;
                image.setRGB(i, j, rgb);
            }
        }
    }

    public void show()
    {
        javax.swing.JFrame frame = new javax.swing.JFrame();
        frame.getContentPane().add(new javax.swing.JLabel(new javax.swing.ImageIcon(image)));
        frame.pack();
        frame.setVisible(true);
    }

    private BufferedImage image;

}