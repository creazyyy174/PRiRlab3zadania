public class Main
{
    public static void main(String[] args)
    {
        int ilosc_watkow=10;
        Thread[] watki=new Thread[ilosc_watkow];
        for(int i=0;i<ilosc_watkow;i++)
        {
            watki[i]=new Thread(String.valueOf(new MonteCarlo(1000000)));
            watki[i].start();
        }
        for(int i=0;i<ilosc_watkow;i++)
        {
            try
            {
                watki[i].join();
            }
            catch(Exception ie)
            {
                System.out.println("Blad watku");
            }
        }
        System.out.println("Wynik: "+MonteCarlo.wynik);
    }
}
