import java.util.Random;

public class MonteCarlo
{
    static double wynik=0;
    int ilosc_punktow;
    public MonteCarlo(int ilosc_punktow)
    {
        this.ilosc_punktow=ilosc_punktow;
    }
    public void start()
    {
        Random rand=new Random();
        double x,y;
        int ilosc_punktow_w_kole=0;
        for(int i=0;i<ilosc_punktow;i++)
        {
            x=rand.nextDouble();
            y=rand.nextDouble();
            System.out.println(x +"   "+ y);
            if(x*x+y*y<=1) ilosc_punktow_w_kole++;
        }
        wynik+=4.0*ilosc_punktow_w_kole/ilosc_punktow;
    }
}
