import java.util.Random;

public class Fraktal_Julii
{
    static int N=1000;
    static int M=1000;
    static int ILE=100;
    static int[][] tab=new int[N][M];
    static int[][] tab2=new int[N][M];
    public static void main(String[] args)
    {
        int a=0;
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<M;j++)
            {
                tab[i][j]=0;
                tab2[i][j]=0;
            }
        }
        for(int i=0;i<ILE;i++)
        {
            a++;
            Fraktal f=new Fraktal();
            f.start();
        }
        while(a>0)
        {
            try
            {
                Thread.sleep(100);
            }
            catch(Exception e)
            {
                System.out.println("Błąd");
            }
            a=0;
            for(int i=0;i<N;i++)
            {
                for(int j=0;j<M;j++)
                {
                    if(tab2[i][j]==0) a++;
                }
            }
        }
        System.out.println("koniec");
    }

    public void run()
    {
        Random rand=new Random();
        double a,b,c,d;
        a=rand.nextDouble()*2-1;
        b=rand.nextDouble()*2-1;
        c=rand.nextDouble()*2-1;
        d=rand.nextDouble()*2-1;
        double x,y;
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<M;j++)
            {
                x=i;
                y=j;
                for(int k=0;k<100;k++)
                {
                    if(x*x+y*y>4)
                    {
                        tab2[i][j]=1;
                        break;
                    }
                    double x1=a*x+b*y;
                    double y1=c*x+d*y;
                    x=x1;
                    y=y1;
                }
                if(tab2[i][j]==0)
                {
                    tab[i][j]++;
                }
            }
        }
    }

    static class Fraktal extends Thread
    {
        public void run()
        {
            Random rand=new Random();
            double a,b,c,d;
            a=rand.nextDouble()*2-1;
            b=rand.nextDouble()*2-1;
            c=rand.nextDouble()*2-1;
            d=rand.nextDouble()*2-1;
            double x,y;
            for(int i=0;i<N;i++)
            {
                for(int j=0;j<M;j++)
                {
                    x=i;
                    y=j;
                    for(int k=0;k<100;k++)
                    {
                        if(x*x+y*y>4)
                        {
                            tab2[i][j]=1;
                            break;
                        }
                        double x1=a*x+b*y;
                        double y1=c*x+d*y;
                        x=x1;
                        y=y1;
                    }
                    if(tab2[i][j]==0)
                    {
                        tab[i][j]++;
                    }
                }
            }
        }
    }
}
