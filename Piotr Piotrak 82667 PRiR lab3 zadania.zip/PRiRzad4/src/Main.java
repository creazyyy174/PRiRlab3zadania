public class Main
{

    public static void main(String[] args)
    {
        Fraktal_Julii fraktal = new Fraktal_Julii();
        fraktal.run();

    }
}
